---
id: mem-1751745020906-7lde0p
key: doc3
created: '2025-07-05T19:50:20.906Z'
updated: '2025-07-05T19:50:20.906Z'
accessed: '2025-07-05T19:50:20.906Z'
accessCount: 0
tags:
  - animal
compressed: false
encrypted: false
---

# doc3

## Value

```
The fox is quick
```

## Metadata

- **Created**: 7/5/2025, 3:50:20 PM
- **Updated**: 7/5/2025, 3:50:20 PM
- **Accessed**: 7/5/2025, 3:50:20 PM (0 times)
- **Tags**: animal
- **Category**: None
