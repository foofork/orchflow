---
id: mem-1751745020916-c415u
key: compressed
created: '2025-07-05T19:50:20.916Z'
updated: '2025-07-05T19:50:20.916Z'
accessed: '2025-07-05T19:50:20.918Z'
accessCount: 1
tags: []
compressed: true
encrypted: false
---

# compressed

## Value

```
{
  "type": "Buffer",
  "data": [
    31,
    139,
    8,
    0,
    0,
    0,
    0,
    0,
    0,
    19,
    237,
    193,
    1,
    13,
    0,
    0,
    0,
    194,
    160,
    218,
    143,
    111,
    14,
    55,
    160,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    224,
    223,
    0,
    163,
    164,
    85,
    13,
    16,
    39,
    0,
    0
  ]
}
```

## Metadata

- **Created**: 7/5/2025, 3:50:20 PM
- **Updated**: 7/5/2025, 3:50:20 PM
- **Accessed**: 7/5/2025, 3:50:20 PM (1 times)
- **Tags**: None
- **Category**: None
