---
id: mem-1751745020839-q65o2
key: object-key
created: '2025-07-05T19:50:20.839Z'
updated: '2025-07-05T19:50:20.839Z'
accessed: '2025-07-05T19:50:20.843Z'
accessCount: 1
tags: []
compressed: false
encrypted: false
---

# object-key

## Value

```
{
  "nested": {
    "data": true
  }
}
```

## Metadata

- **Created**: 7/5/2025, 3:50:20 PM
- **Updated**: 7/5/2025, 3:50:20 PM
- **Accessed**: 7/5/2025, 3:50:20 PM (1 times)
- **Tags**: None
- **Category**: None
