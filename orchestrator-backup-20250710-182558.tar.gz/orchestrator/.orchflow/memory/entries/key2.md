---
id: mem-1751745021408-po7gai
key: key2
created: '2025-07-05T19:50:21.408Z'
updated: '2025-07-05T19:50:21.408Z'
accessed: '2025-07-05T19:50:21.408Z'
accessCount: 0
tags: []
compressed: true
encrypted: false
---

# key2

## Value

```
{
  "type": "Buffer",
  "data": [
    31,
    139,
    8,
    0,
    0,
    0,
    0,
    0,
    0,
    19,
    171,
    86,
    74,
    73,
    44,
    73,
    84,
    178,
    82,
    42,
    75,
    204,
    41,
    77,
    53,
    82,
    170,
    5,
    0,
    20,
    129,
    169,
    62,
    17,
    0,
    0,
    0
  ]
}
```

## Metadata

- **Created**: 7/5/2025, 3:50:21 PM
- **Updated**: 7/5/2025, 3:50:21 PM
- **Accessed**: 7/5/2025, 3:50:21 PM (0 times)
- **Tags**: None
- **Category**: None
