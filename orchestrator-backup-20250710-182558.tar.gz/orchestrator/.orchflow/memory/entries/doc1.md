---
id: mem-1751745020897-m86ed
key: doc1
created: '2025-07-05T19:50:20.897Z'
updated: '2025-07-05T19:50:20.897Z'
accessed: '2025-07-05T19:50:20.897Z'
accessCount: 0
tags: []
compressed: false
encrypted: false
---

# doc1

## Value

```
The quick brown fox
```

## Metadata

- **Created**: 7/5/2025, 3:50:20 PM
- **Updated**: 7/5/2025, 3:50:20 PM
- **Accessed**: 7/5/2025, 3:50:20 PM (0 times)
- **Tags**: None
- **Category**: None
